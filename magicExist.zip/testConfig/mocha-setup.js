require('@babel/register');
require('./dom');
require('./helpers');
require('./ignores');