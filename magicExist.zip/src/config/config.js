export default {
    defaultUser: {
        userName: "userName",
        token: "",
        password: "",
        email: "",
        photo: "",
        errorMessage: "",
    },
    defaultMode: "chats",
    defaultMessages: [],
    defaultAllUsers: [],
    defaultLocale: "en",
    defaultUsersFilter: "",
    defaultActiveChat: "",
    defaultSettingsMode: "profile",
    emojiState: false,
    defaultMessageFilter: "",
}