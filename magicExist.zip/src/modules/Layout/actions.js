import actionTypes from "../../constants/actionTypes";

export const ageUp = () => ({ type: actionTypes.AGE_UP });
export const ageDown = () => ({ type: actionTypes.AGE_DOWN });