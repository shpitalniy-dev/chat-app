export const getAge = state => state.age.age;
