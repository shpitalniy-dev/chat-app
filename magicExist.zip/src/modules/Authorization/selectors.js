export const getDictionary = state => state.translates.dictionary;
export const getUser = state => state.common.user;