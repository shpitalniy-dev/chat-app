import actionTypes from "../../constants/actionTypes";

export const loginRequest = payload => ({ type: actionTypes.LOGIN_REQUEST_ASYNC, payload });