export const getUser = state => state.common.user;
export const getDictionary = state => state.translates.dictionary;