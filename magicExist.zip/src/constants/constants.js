export default {
    en: "en",
    ru: "ru",
    ar: "ar",
    serverUrl: "https://immense-brook-86861.herokuapp.com/",
    wsPath: "ws://immense-brook-86861.herokuapp.com/ws-chat",
}